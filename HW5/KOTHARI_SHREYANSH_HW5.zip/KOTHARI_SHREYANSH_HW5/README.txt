Name: Shreyansh Kothari
USCID: 1233-6880-18
Email: shreyank@usc.edu
Version: Visual Studio 2013

HW5 - Completed
open the .sln file, build and run.
Completed Texture for phong and gouraud shading with interpolation and perspective correction
Procedural texture : checkered pattern :)
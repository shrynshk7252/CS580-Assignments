//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CS580HW.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_CS580HTYPE                  129
#define IDI_ICON1                       130
#define IDD_ROTATE                      132
#define IDD_TRANSLATE                   133
#define IDD_SCALE                       134
#define IDC_RADIO_ROTX                  1003
#define IDC_RADIO_ROTY                  1004
#define IDC_RADIO_ROTZ                  1005
#define IDC_EDIT_ROT                    1006
#define IDC_EDIT_TX                     1007
#define IDC_EDIT_TZ                     1008
#define IDC_EDIT_TY                     1009
#define IDC_EDIT_SX                     1010
#define IDC_EDIT_SY                     1011
#define IDC_EDIT_SZ                     1012
#define IDM_RENDER                      32771
#define IDM_OBJ_TRX                     32772
#define IDM_ROTATE                      32773
#define IDM_TRANSLATE                   32774
#define IDM_SCALE                       32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

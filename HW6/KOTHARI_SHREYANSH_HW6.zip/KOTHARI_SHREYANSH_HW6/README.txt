Name: Shreyansh Kothari
USCID: 1233-6880-18
Email: shreyank@usc.edu
Version: Visual Studio 2013

HW6 - Completed
open the CS580HW5.sln file, build and run. (forgot to change names to HW6 :P)
Anti Aliasing - Done